import * as TYPES from "../action-types";
const storeAction = {};

export default storeAction;
