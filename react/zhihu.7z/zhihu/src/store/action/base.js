import * as TYPES from "../action-types";
const baseAction = {};

export default baseAction;
