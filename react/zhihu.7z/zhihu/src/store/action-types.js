export const BASE_INFO = "BASE_INFO";
