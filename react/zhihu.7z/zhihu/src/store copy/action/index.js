import baseAction from './base';
import storeAction from './store';

const action = {
    base: baseAction,
    store: storeAction
};
export default action;