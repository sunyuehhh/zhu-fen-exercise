export const BASE_INFO = "BASE_INFO";

export const STORE_LIST = "STORE_LIST";
export const STORE_REMOVE = "STORE_REMOVE";